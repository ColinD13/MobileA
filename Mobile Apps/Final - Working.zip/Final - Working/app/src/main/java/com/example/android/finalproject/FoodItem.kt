package com.example.android.finalproject

data class FoodItem(val name: String, val imageResId: Int)

package com.example.android.finalproject

data class MenuItem(val title: String, val iconResId: Int)
